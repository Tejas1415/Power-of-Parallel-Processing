# -*- coding: utf-8 -*-
import numpy as np
import argparse
from time import time
from operator import add
from pyspark import SparkContext

def readDataRDD(input_file,N,spark_context):
    """  Read data from an input file. Each line of the file contains tuples of the form

                    (x,y)  

         x is an array of values for each feature

         and y is a binary value +1 or -1.

         The return value is an RDD containing tuples of the form
                 (x,y)             

    """ 
    return spark_context.textFile(input_file)\
                        .map(lambda line: line.split(',')[1:])\
                        .map(lambda line: np.array([eval(x) for x in line]))\
                        .map(lambda line: (line[1:],line[0]))\
                        .mapValues(lambda y: -1 if not y else y)\
                        .repartition(N).cache()

def readBalancedRDD(input_file,N,spark_context):
    """ The input file for the balanced data set is slightly differently formatted.
        Use this function for the balanced data set. Assumes the variable names has
        been removed
        
        Each line of the file contains the following form:
        [(x),y]
        Where x is a tuple of values for each feature,
        
        and y is a binary value 0 or 1.
        
        Returns and RDD containing tuples of the form
            (x,y), where y is a binary value -1 or +1
        
    """
    return spark_context.textFile(input_file)\
                        .map(lambda line: eval(line))\
                        .map(lambda (x,y):(np.array(x),y))\
                        .mapValues(lambda y: -1 if not y else y)\
                        .repartition(N).cache()
                        
def writePerformance(output,performance,lam,fold):
    """ Write an array of perfomance measures to a file ouptut.  Each line of output contains the following values for a single iteration:
                gradNorm,k,time,accuracy,precision,recall
 
    """
    with open(output +'perfomance_lam'+str(lam)+'fold'+str(fold), 'w') as fh:
        for iteration in performance:
            fh.write(','.join(map(str,iteration))+'\n')

def writeBeta(output,beta,lam):
    """ Write a vector β to a CSV file ouptut
    """
    with open(output+'beta_lam'+str(lam),'w') as fh:
	fh.write(','.join(map(str, beta.tolist()))+'\n')

def predict(x,beta):
    """ Given vector x containing features and parameter vector β, 
	return the predicted value: 

	                y = <x,β>   

    """ 
    return(np.dot(beta,x))    
            
def logisticLoss(beta,x,y):
    """
        Given beta as an array, x as an array, and a binary value y in {-1,+1}, compute the logistic loss
               
                l(β;x,y) = log( 1.0 + exp(-y * <β,x>) )

	The input is:
	    - beta: a vector β
	    - x: a vector x
            - y: a binary value in {-1,+1}

    """
    return (np.log(1.0 + np.exp(-1.0*y * np.dot(beta,x))))

    
def gradLogisticLoss(beta,x,y):
    """
        Given beta as an array, x as an array, and
        a binary value y in {-1,+1}, compute the gradient of the logistic loss 

              ∇l(B;x,y) = -y / (1.0 + exp(y <β,x> )) * x

	The input is:
	    - beta: a vector β
	    - x: a vector x
            - y: a binary value in {-1,+1}


    """
    return (-1.0*y /(1.0 + np.exp(y * np.dot(beta,x)))*x)

def linearLoss(beta,x,y):
    """ Given vector x containing features, true label y, 
	and parameter vector β, return the square error:

	         f(β;x,y) =  (y - <x,β>)^2	

    """
    return((y-predict(x,beta))**2)

def gradLinearLoss(beta,x,y):
    """ Given vector x containing features, true label y, 
	and parameter vector β, return the gradient ∇f of f:

	        ∇f(β;x,y) =  -2 * (y - <x,β>) * x	

        with respect to parameter vector β.

        The return value is  ∇f.
    """
    return(-2*(y-predict(x,beta))*x)    

def totalLossRDD(dataRDD,beta,linLog,lam = 0.0):
    """  Given a vector beta and a dataset  compute the regularized total logistic loss :
              
               L(β) = Σ_{(x,y) in data}  l(β;x,y)  + λ ||β ||_2^2             
        
         Inputs are:
            - dataRDD: an RDD list containing pairs of the form (x,y), where x is a vector and y is a binary value
            - beta: a vector β
            - lam: the regularization parameter λ
    """
    if linLog:
        f = lambda (x,y):linearLoss(beta,x,y)
    else:
        f = lambda (x,y):logisticLoss(beta,x,y)
    loss = dataRDD.map(f).reduce(add)
    return(loss + lam + np.dot(beta,beta))

def gradTotalLossRDD(dataRDD,beta,linLog,lam = 0.0):
    """  Given a vector beta and a dataset perform compute the gradient of regularized total logistic loss :
            
              ∇L(β) = Σ_{(x,y) in data}  ∇l(β;x,y)  + 2λ β   
        
         Inputs are:
            - dataRDD: an RDD containing pairs of the form (x,y), where x is a vector and y is a binary value
            - beta: a vector β
            - linLog: 1 for linear regression, 0 for logistic regression
            - lam: the regularization parameter λ
    """
    if linLog:
        gradFun = lambda (x,y): gradLinearLoss(beta,x,y)
    else:
        gradFun = lambda (x,y): gradLogisticLoss(beta,x,y)
        
    gradLoss = dataRDD.map(gradFun).reduce(add)
    return(gradLoss + 2.0*lam*beta)

def lineSearch(fun,x,grad,fx,gradNormSq, a=0.2,b=0.6):
    """ Given function fun, a current argument x, and gradient grad=∇fun(x), 
        perform backtracking line search to find the next point to move to.
        (see Boyd and Vandenberghe, page 464).

	
        Inputs are:
	    - fun: the objective function f.
	    - x: the present input (a Vector)
            - grad: the present gradient (as Vector)
            - fx: precomputed f(x) 
            - grad: precomputed ∇f(x)
            - Optional parameters a,b  are the parameters of the line search.

        Given function fun, and current argument x, and gradient grad=∇fun(x), the function finds a t such that
        fun(x - t * ∇f(x)) <= f(x) - a * t * <∇f(x),∇f(x)>

        The return value is the resulting value of t.
    """
    t = 1.0
    while fun(x-t*grad) > fx- a * t * gradNormSq:
        t = b * t
    return t    
    
def AUC(scores):
    """
    Given the RMSE scores of a test set as an RDD, calculates the area under the curve. 
    The scores are given as tuples of the following form:
    (score, y)
    where y is the ground truth label of the sample. 
    
    returns a scalar value for the area under the curve
    """
    P = len( [x for x in scores if x[1] >0  ])
    N = len( [x for x in scores if x[1] <=0  ]) 
    zipped = sorted(scores) 
    auc = 0.0
    count = 0.0    
    for score in zipped:
        if score[1] < 0:
            count += 1.0/N
        else:
            auc += count/P 
    return auc
     
def test(dataRDD,beta,Mtest,linLog,lam=0.0):
    """ Output the quantities necessary to compute the accuracy, precision, and recall of the prediction of labels in a dataset under a given β.
        
        The accuracy (ACC), precision (PRE), and recall (REC) are defined in terms of the following sets:

                 P = datapoints (x,y) in data for which <β,x> > 0
                 N = datapoints (x,y) in data for which <β,x> <= 0
                 
                 TP = datapoints in (x,y) in P for which y=+1  
                 FP = datapoints in (x,y) in P for which y=-1  
                 TN = datapoints in (x,y) in N for which y=-1
                 FN = datapoints in (x,y) in N for which y=+1

        For #XXX the number of elements in set XXX, the accuracy, precision, and recall of parameter vector β over data are defined as:
         
                 ACC(β,data) = ( #TP+#TN ) / (#P + #N)
                 PRE(β,data) = #TP / (#TP + #FP)
                 REC(β,data) = #TP/ (#TP + #FN)
                 AUC = area under the curve

        Inputs are:
             - dataRDD: an RDD containing pairs of the form (x,y)
             - beta: vector β
             - Mtest: the number of test samples
             - linLog: 1 for linear regression, 0 for logistic regression
             - lam: regularization parameter

        The return values are
             - ACC, PRE, REC, testRMSE, AUC
       
    """
    c = dataRDD.map(lambda (x,y): (np.dot(beta,x),y)).cache()
    testRMSE = np.sqrt(1.*totalLossRDD(dataRDD,beta,linLog,lam)/Mtest)
    p = c.filter(lambda (ypred,y): ypred>=0).cache()
    n = c.filter(lambda (ypred,y): ypred<0).cache()
    nump = p.count()
    numn = n.count()
    tp = p.filter(lambda (ypred,y): y==1).count()
    fp = nump-tp
    tn = n.filter(lambda (ypred,y): not(y==1)).count()
    fn = numn-tn  
    
    acc = float(tp+tn)/float(nump+numn)
    pre = float(tp)/float(1 if not tp+fp else tp+fp)
    rec = float(tp)/float(1 if not tp+fn else tp+fn)
    
    auc = AUC(c.collect())
    
    return(acc,pre,rec,testRMSE,auc)

def train(dataRDD,beta_0,lam,max_iter,eps,performanceFolder,fold,linLog,test_data=None,Mtest=None):
    """
    Perform logistic regression:
 

	where
             - dataRDD: an rdd containing pairs of the form (x,y)
             - beta_0: the starting vector β
             - lam:  is the regularization parameter λ
             - max_iter: maximum number of iterations of gradient descent
             - eps: upper bound on the l2 norm of the gradient
             - performanceFolder: the save location of the performance statistics
             - fold: the number of the current fold
             - linLog: 1 for linear regression 0 for logistic regression
             - Mtest: number of test samples
             - test_data: the validation data to be used
 

	The function returns:
	     -beta: the trained β, 
	     -gradNorm: the norm of the gradient at the trained β, and
             -k: the number of iterations performed
    """
    dataRDD = dataRDD.cache()
    performance = []
    k = 0
    gradNorm = 2*eps
    beta = beta_0
    start = time()
    while k<max_iter and gradNorm > eps:
        obj = totalLossRDD(dataRDD,beta,linLog,lam)
        
        grad = gradTotalLossRDD(dataRDD,beta,linLog,lam=lam)
        gradNormSq = np.dot(grad,grad)
        gradNorm = np.sqrt(gradNormSq)
        
        fun = lambda x: totalLossRDD(dataRDD,x,linLog,lam=lam)
        gamma = lineSearch(fun,beta,grad,obj,gradNormSq)
        
        beta = beta - gamma * grad
        if test_data == None:
            t = time()-start
            print 'k = ',k,'\tt = ',t,'\tL(β_k) = ',obj,'\t||∇L(β_k)||_2 = ', gradNorm,'\tgamma = ',gamma
        else:
            acc,pre,rec,testRMSE,auc = test(test_data,beta,Mtest,linLog,lam)
            t = time()-start
            print 'k = ',k,'\tt = ',t,'\tL(β_k) = ',obj,'\t||∇L(β_k)||_2 = ',gradNorm,'\tgamma = ',gamma,'\tACC = ',acc,'\tPRE = ',pre,'\tREC = ',rec, '\tAUC = ', auc
            performance.append([testRMSE, gradNorm, k, t, acc, pre, rec, auc])
        k = k + 1
        
    writePerformance(performanceFolder,performance,lam,fold)
        
    return beta, gradNorm, k, testRMSE
    
if __name__=="__main__":
        

    parser = argparse.ArgumentParser(description = 'Parallel Logistic Regression.',formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('data',help = 'Directory containing folds. The folds should be named fold0, fold1, ..., foldK.')
    parser.add_argument('folds',type = int,help = 'Number of folds')
    parser.add_argument('linLog',help = '1 for linear regression, 0 for logistic')
    parser.add_argument('--eps',default=1.e-99,type=float,help ="Desired objective accuracy")
    parser.add_argument('--lam',default=1.0,type=float,help ="Regularization parameter for user features")
    parser.add_argument('--beta',help = 'Output file for beta')
    parser.add_argument('--perfOut', help = 'Output file for the performance stats')
    parser.add_argument('--maxiter',default=20,type=int, help='Maximum number of iterations')
    parser.add_argument('--N',default=40,type=int, help='Parallelization Level')
    parser.add_argument('--output',default=None, help='If not None, cross validation is skipped, and U is trained over entire dataset and store it in files output_U and output_V')

    verbosity_group = parser.add_mutually_exclusive_group(required=False)
    verbosity_group.add_argument('--verbose', dest='verbose', action='store_true')
    verbosity_group.add_argument('--silent', dest='verbose', action='store_false')
    parser.set_defaults(verbose=False)

 
    args = parser.parse_args()

    sc = SparkContext(appName='Parallel Logistic Regression')
    
    if not args.verbose :
        sc.setLogLevel("ERROR")        

       

    folds = {}

    print "Reading data"
    if args.output is None:
        for k in range(args.folds):
            folds[k] = readBalancedRDD(args.data+"/fold"+str(k),args.N,sc)
    else:
        folds[0] = readBalancedRDD(args.data,sc)

      
    print "Constructing Folds"
    linLog = int(args.linLog)
    lam = args.lam
    cross_val_rmses = []
    for k in folds:
        train_folds = [folds[j] for j in folds if j is not k ]

        if len(train_folds)>0:
            trainData = train_folds[0]
            for fold in  train_folds[1:]:
                trainData=trainData.union(fold)
            trainData.repartition(args.N).cache()
            testData = folds[k].repartition(args.N).cache()
            Mtrain=trainData.count()
            Mtest=testData.count()
              
            print("Initiating fold %d with %d train samples and %d test samples" % (k,Mtrain,Mtest) )
        else:
            trainData = folds[k].repartition(args.N).cache()
            testData = train
            Mtrain=trainData.count()
            Mtest=testData.count()
            print("Running single training over training set with %d train samples. Test RMSE computes RMSE on training set" % Mtrain )
        
        x = trainData.take(1)
        dim = len(x[0][0])
        beta0 = np.zeros(dim)
        print("Training sample has %d dimensions" %dim)
        print 'Training on data from', args.data, 'with λ =',args.lam,',ε =',args.eps,', max iter = ',args.maxiter
        beta, gradNorm, i, testRMSE = train(trainData,linLog=linLog,beta_0=beta0,lam=lam,max_iter=args.maxiter,eps=args.eps,performanceFolder=args.perfOut,fold=k,test_data=testData,Mtest=Mtest)
        print 'Algorithm ran for',i,'iterations. Converged:',gradNorm<args.eps
        print 'Saving trained β in',args.beta
        writeBeta(args.beta +'fold'+str(k),beta,lam)
        
            
        cross_val_rmses.append(testRMSE)

        trainData.unpersist()
        testData.unpersist()

    if args.output is None:
       print "%d-fold cross validation error is: %f " % (args.folds, np.mean(cross_val_rmses))
    else:
       print "Saving U and V RDDs"