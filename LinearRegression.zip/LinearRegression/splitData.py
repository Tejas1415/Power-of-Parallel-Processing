from pyspark import SparkContext
import numpy as np

def balancedData(dataRDD,N):
    class1 = dataRDD.filter(lambda (x,y):y==1)
    class2 = dataRDD.filter(lambda (x,y):y==0).sample(withReplacement=False,fraction=0.111)
    return class1.union(class2).repartition(N).cache()

def makeFolds(input_file,spark_context):
    temp = spark_context.textFile(input_file)\
                .map(lambda line: line.split(',')[1:])\
                .map(lambda line: np.array([eval(x) for x in line]))\
                .map(lambda line: (line[1:],line[0]))\
                .repartition(40).cache()

    folds= balancedData(temp,40)\
                .randomSplit([0.2, 0.2, 0.2, 0.2, 0.2])
                
    for k in range(len(folds)):
        tempfold = folds[k].map(lambda (x,y):'('+np.array2string(x,separator=',').replace('\n','')+','+str(y)+')\n').collect()
        print(type(tempfold))
        print(len(tempfold))
        fw = open("balancedFolds/fold"+str(k),"w")
        fw.writelines(tempfold)
        fw.close()
    