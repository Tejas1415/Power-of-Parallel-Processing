#!/bin/bash
#SBATCH --output=output/equalDataSet/log/regression_%j.out
#SBATCH --job-name=KresseFinalProj
#SBATCH --error=output/equalDataSet/log/regression_%j.err
#SBATCH --reservation=eece5698
#SBATCH --mem 100G
#SBATCH --nodes=1
#SBATCH --exclusive

spark-submit --executor-memory 100G --driver-memory 100G ParallelRegression_kfoldCV.py equalFolds 5 $1 --N 40 --maxiter $2 --beta output/equalDataSet/log/beta/ --perfOut output/equalDataSet/log/perf/ --lam $3
