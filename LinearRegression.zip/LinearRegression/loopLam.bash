#!/bin/bash
#SBATCH --reservation=eece5698
#SBATCH --error=output/equalDataSet/loopLam_%j.err
#SBATCH --output=output/equalDataSet/master_loop_%j.out
for lam in `seq 0 1 20`
do 
	work=/scratch/$USER/FinalProj/
	cd $work
	sbatch regression.bash 0 20 $lam

done
