import os
import argparse
import numpy as np
from read_equal_data import load_data
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_curve, auc

def run_model():
    import keras
    import tensorflow as tf
    from keras.layers import Dense
    from keras.models import Sequential

    seed = 7
    np.random.seed(seed)

    with tf.device("/cpu:0"):
        X, Y = load_data('./')
        
        all_scores = []
        all_fpr = []
        all_tpr = []
        all_roc_auc = []

        kfold=StratifiedKFold(n_splits=4, shuffle=True, random_state=seed)

        for train, test in kfold.split(X,Y):
            model = Sequential()
            model.add(Dense(41098, activation='relu'))
            model.add(Dense(1024, activation='relu'))
            model.add(Dense(1, activation='sigmoid'))
            model.compile(loss='mean_squared_error', optimizer='sgd', metrics=['accuracy']) 
            model.fit(X[train],Y[train], epochs=1, batch_size=10)
            scores = model.evaluate(X[test], Y[test])

            y_score = model.predict(X[test]).ravel()
            
            fpr = []
            tpr = []
            roc_auc = []
            fpr, tpr, _ = roc_curve(Y[test], y_score, pos_label=1)
            roc_auc = auc(fpr, tpr)
            ''' 
            all_fpr = np.unique(np.concatenate([fpr[i] for i in range(200)]))
            mean_tpr = np.zeros_like(all_fpr)
            for i in range(n_classes):
                mean_tpr += interp(all_fpr, fpr[i], tpr[i])
            mean_tpr /= 200
            fpr = all_fpr
            tpr = mean_tpr
            roc_auc = auc(fpr, tpr)            
            '''
            print 'Accuracy: ', scores[1]*100
            all_scores.append(scores[1] * 100)
            '''
            print 'True Positive Rate: ', tpr
            print 'False Positive Rate: ', fpr
            print 'AUC: ', roc_auc
            all_scores.append(scores[1] * 100)
            
            all_fpr.append(fpr)
            all_tpr.append(tpr)
            all_roc_auc.append(roc_auc)
            '''
        print("Accuracy: %.2f%% (+/- %.2f%%)" % (np.mean(all_scores), np.std(all_scores))) 
        print 'True Positive Rate: ', np.mean(all_tpr), '(+/- ',  np.std(all_tpr), ')'
        print 'False Positive Rate: ', np.mean(all_fpr), '(+/- ',  np.std(all_fpr), ')'
        print 'AUC: ', np.mean(all_roc_auc), '(+/- ',  np.std(all_roc_auc), ')'


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('id_gpu', type=int, default=0)
    args = parser.parse_args()
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.id_gpu)

    run_model()


