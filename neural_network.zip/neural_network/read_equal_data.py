import time
import os
import pickle
import argparse
import numpy as np
from tqdm import tqdm
from sklearn.preprocessing import StandardScaler

def load_data(stats_path):
    x_train_path = os.path.join(stats_path, 'x_train_eq.pkl')
    y_train_path = os.path.join(stats_path, 'y_train_eq.pkl')

    x_train = pickle.load(open(x_train_path, 'rb'))
    y_train = pickle.load(open(y_train_path, 'rb'))

    x_train = x_train.astype(float)
    
    
    start_time = time.time()
    x_train = StandardScaler().fit_transform(x_train)
    print 'Sklearn normalizing time: ', time.time()-start_time, 's'

    return x_train, y_train

def save_data(stats_path):
    train_path = stats_path
    x_train, y_train = [], []

    if os.path.exists(train_path):
        with open(train_path) as train_file:
            for idx, line in tqdm(enumerate(train_file), total=41098):
                if not idx:
                    continue
                line = line[:-2]
                line = line.split(',')[1:]
                y_train.append(line[0])
                x_train.append(line[1:])

    pickle.dump(np.array(x_train), open('x_train_eq.pkl','wb'))
    pickle.dump(np.array(y_train), open('y_train_eq.pkl','wb'))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--fun', type=str, help="Either save or load data. {save | load}",
                        default='save')
    parser.add_argument('stats_path', type=str, help='Path containing csv files')
    args = parser.parse_args()
    if args.fun == 'save':
        save_data(args.stats_path)
    if args.fun == 'load':
        load_data(args.stats_path)
