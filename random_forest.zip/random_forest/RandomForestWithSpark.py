# -*- coding: utf-8 -*-
"""
Created on Thu Apr 11 11:17:00 2019

@author: Tejas

Santander Bank Customer Transaction Prediction - Kaggle compitition. 

Program With Spark  
"""

import pyspark
import csv
from pyspark import SQLContext 
from pyspark.ml.feature import StandardScaler
from pyspark import SparkContext
from pyspark.sql import SparkSession
import numpy as np
import time


########### Build a Spark Session and load the csv file ###############

spark = SparkSession.builder \

    .appName("Advantages of Spark") \
    .master("local[*]") \
    .getOrCreate()

df = spark.read.options(header = "true", inferschema = "true").csv('equalDataSet1.csv')

print("Total number of rows: %d" % df.count())
# Output = 200,000

############## Now do Standard Scaler Normalization for the data #############

from pyspark.ml.feature import StandardScaler
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.linalg import Vectors
from pyspark.mllib.regression import LabeledPoint

start1 = time.time()

### All features
allFeatures = np.array(df.columns[1:]) #First col is ID_Code which is not useful, and second is the label.

## Assemble all feature columns into a dense matrix named features
assembler = VectorAssembler().setInputCols(allFeatures).setOutputCol("features")

##Transform the recognised columns of features in df for further calculations. 
transformVector = assembler.transform(df) 

##Now we have combined the features, so we can delete the individual features
transformVector = transformVector.drop(str(df.columns[1:200]))

## Build a standard scaling algorithm model with mean and SD
scaler = StandardScaler().setInputCol("features").setOutputCol("scaledFeatures").setWithStd(True).setWithMean(True)

start2 = time.time()
## computing the statistics like mean, std for every feature, that are required for StandardScaler
scalerModel = scaler.fit(transformVector)

end2 = time.time()

## Now, using the above calculated parameters and finally normalizing the values.
scaledData = scalerModel.transform(transformVector)

end1 = time.time()


scaledData.show(2)
print("time taken for StandardScaler Normalization in Spark =", end2 - start2)

################################ Random Forest Algorithm - Spark Based ##################

from pyspark.mllib.linalg import Vectors
from pyspark.mllib.regression import LabeledPoint


### All features
allFeatures = np.array(df.columns[1:]) #First col is ID_Code which is not useful, and second is the label.

## Assemble all feature columns into a dense matrix named features
assembler = VectorAssembler().setInputCols(allFeatures).setOutputCol("features")

##Transform the recognised columns of features in df for further calculations. 
transformVector = assembler.transform(df) 

(training_data, testing_data) = transformVector.randomSplit([0.85, 0.15])


#### Random Forest in Spark ####
from pyspark.ml.classification import RandomForestClassifier

start_random = time.time()
rf = RandomForestClassifier(labelCol="target", featuresCol="features", numTrees=10)
model = rf.fit(training_data)
end_random = time.time()

start_prediction = time.time()
predictions = model.transform(training_data)
end_prediction = time.time()
print("Random Forest training time = ", end_random - start_random)
print("Random Forest testing time =", end_prediction - start_prediction )

#################### AUC Score to check the accuracy of the results ####################

predictions = rf.predict(testing_data.map(lambda x: x.features))
labels_and_predictions = testing_data.map(lambda x: x.target).zip(predictions)
acc = labels_and_predictions.filter(lambda x: x[0] == x[1]).count() / float(testing_data.count())
print("Model accuracy: %.3f%%" % (acc * 100))

from pyspark.mllib.evaluation import BinaryClassificationMetrics

start_time2 = time()

metrics = BinaryClassificationMetrics(labels_and_predictions)
print("Area under Precision/Recall (PR) curve: %.f" % (metrics.areaUnderPR * 100))
print("Area under Receiver Operating Characteristic (ROC) curve: %.3f" % (metrics.areaUnderROC * 100))

end_time2 = time()
elapsed_time = end_time2 - start_time2
print("Time to evaluate model: %.3f seconds" % elapsed_time)


################## Print the feature importances and then run the random forest algorithm above on the reduced feature set

feature_importance_scores = model.featureImportances

print (feature_importance_scores)

#If we threshold the importance score to 0.04, then we can remove the least 70 important features from every data point.
# Accuracy produced after removing least 70 features was 72%. which is only 2-3% less than the actual full dataset.









