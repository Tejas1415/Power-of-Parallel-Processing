# -*- coding: utf-8 -*-
"""
Created on Thu Apr 11 11:17:00 2019

@author: Tejas

Santander Bank Customer Transaction Prediction - Kaggle compitition. 

Program Without Spark  
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import math
from sklearn.linear_model import LinearRegression
from sklearn import cross_validation, svm, preprocessing
from sklearn.metrics import mean_squared_error, r2_score


# Input the test and Train datasets
df = pd.read_csv('train.csv')

# Visualise the data
df.head()

# Remove ID_code - Not an imp feature
df.drop(['ID_code'], 1, inplace = True)



####################### Trying to take 20,000 1's and 20,000 0's and use that as the data ##############
df1 = df.loc[df['target'] == 1]
df0 = df.loc[df['target'] == 0]       # Extracting all 0's. Now will shuffle and take 20k data from this and attach that to df1.

df00 = df0.sample(n=20100, replace = False, random_state = 42)  #Extracted 21k elements randomly.

dataframes = [df1, df00]
dfFinal = pd.concat(dataframes)

#dfFinal.to_csv('equalDataSet1.csv')
######################## Test Set and Training Set ##################################
# Define features and labels

#dfFinal = df
X = np.array(dfFinal.drop(['target'], 1))  # everything exept target
y = np.array(dfFinal['target'])            # target is the label

#Divide training set into train and test sets
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state = 42)
print (X_train.shape, y_train.shape)
print (X_test.shape, y_test.shape)

# Preprocessing X in a way it produces better results.
"""
Feature Scaling - Standard Scaling technique 
(Because this works best for SVM's, logistic regression, and other classification algorithms)
 
1. For every feature (column), find mean.
2. Subtract mean from each value in the column.
3. Divide the answer with the standard deviation of initial column.

"""
from sklearn.preprocessing import StandardScaler
import time
start = time.time()
X_train = StandardScaler().fit_transform(X_train)
X_test = StandardScaler().fit_transform(X_test)
end = time.time()

print ("Time Without Spark = ", end - start)


########################## PreProcessing Complete #############################

from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier 

# getiing 100% and 76.5% train n test acc - (n = 500)
rf = RandomForestClassifier(n_estimators = 500,
                           n_jobs = -1,
                           oob_score = True,
                           max_features = 5,
                           max_depth = 8,
                           min_samples_leaf = 4,
                           random_state = 42)

# Calculate Model Training time
model_start_time = time.time()
rf.fit(X_train, y_train)
model_end_time = time.time()

print("Time taken to train the model for the given dataset = ", model_end_time - model_start_time)
# Output 14.2747280 secs

rf.get_params() ## To check the automatic hyperparameters chosen by Rf.

## Building an algorithm is fast in Random forests but predicting results consumes considerable amount of time.
testing_start_time = time.time()
rf.predict(X_train)
testing_end_time = time.time()
print ("testing_time = ", testing_end_time - testing_start_time)
# output 0.547907352 secs



from sklearn.metrics import r2_score, accuracy_score
from sklearn.metrics import roc_curve, auc 

print ("Training Accuracy: ", accuracy_score(y_train, rf.predict(X_train)))
print ("Testing Accuracy: ",  accuracy_score(y_test, rf.predict(X_test)))
    
time_AUC_start = time.time()      
false_positive_rate, true_positive_rate, thresholds = roc_curve(y_test, rf.predict(X_test))
roc_auc = auc(false_positive_rate, true_positive_rate)
time_AUC_end = time.time()
print ("AUC Score: ", roc_auc)   ## AUC score is better 
print ("False Positive Rate = ", false_positive_rate[1])
print ("True Positive Rate = ", true_positive_rate[1])

print("Time taken to calculate AUC score =", time_AUC_end - time_AUC_start)
#Output 0.2390 s

########### Compare predicted and original values visually ####################
y_predicted = rf.predict(X_test)
c = np.transpose(np.array([y_predicted, y_test])) # Just to visualise the results side by side.


################ Now producing feature importances #####################
names = np.array(range(0,200))
print ("Features sorted by their score:")
feature_scores = sorted(zip(map(lambda x: round(x, 4), rf.feature_importances_), names), reverse=True)
print (sorted(zip(map(lambda x: round(x, 4), rf.feature_importances_), names), reverse=True))

# Better to delete the features of importance less than 0.0040 - That is 70 features among 700 will be deleted.
keep = []
discard = []
for var in feature_scores:
    imp = var[0]
    feature = var[1]
    if imp > 0.0040:
        keep.append(feature)
    else:
        discard.append(feature)

# Discard unwanted features
X_train = np.delete(X_train, discard, 1)  # 1 represents columns
X_test = np.delete(X_test, discard, 1)
# This can be used for further modeling purposes.
